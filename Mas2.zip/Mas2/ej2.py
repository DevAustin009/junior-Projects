from tkinter import *

master = Tk()
elements = StringVar()

lista = Listbox(master)

for items in ['Abel', 'Manuel', 'David', 'Rolando', 'Daniel', 'Marie', 'Jack']:

    lista.insert(END, items)
lista.pack()

Label = Label(text='Lista de Nombres')
Label.pack()
master.mainloop()
